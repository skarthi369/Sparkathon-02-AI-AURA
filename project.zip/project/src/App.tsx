import React, { useState } from 'react';
import Header from './components/Header';
import TextInput from './components/TextInput';
import Summary from './components/Summary';
import SummaryHistory from './components/SummaryHistory';
import ErrorMessage from './components/ErrorMessage';
import Features from './components/Features';
import HowItWorks from './components/HowItWorks';
import Footer from './components/Footer';
import { useSummarizer } from './hooks/useSummarizer';
import { Summary as SummaryType } from './types';

function App() {
  const { loading, error, summaries, generateSummary, clearHistory, deleteSummary } = useSummarizer();
  const [currentSummary, setCurrentSummary] = useState<SummaryType | null>(null);
  
  const handleSubmit = async (text: string, tone: SummaryType['tone'], length: SummaryType['length']) => {
    const summary = await generateSummary(text, tone, length);
    if (summary) {
      setCurrentSummary(summary);
    }
  };
  
  const handleClearError = () => {
    // This would be implemented with a state setter if error state was managed in this component
  };
  
  const handleSelectSummary = (summary: SummaryType) => {
    setCurrentSummary(summary);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <Header />
      
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
          <h1 className="text-3xl font-bold text-center text-gray-900 mb-8">
            Transform Long Articles into Concise Summaries
          </h1>
          
          <div className="mb-12">
            {error && <ErrorMessage message={error} onClose={handleClearError} />}
            <TextInput onSubmit={handleSubmit} isLoading={loading} />
            {currentSummary && <Summary summary={currentSummary} />}
          </div>
          
          <Features />
          
          <HowItWorks />
          
          <section id="history" className="py-12">
            <SummaryHistory
              summaries={summaries}
              onSelect={handleSelectSummary}
              onDelete={deleteSummary}
              onClearAll={clearHistory}
            />
          </section>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

export default App;