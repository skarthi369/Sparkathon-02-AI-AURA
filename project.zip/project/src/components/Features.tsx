import React from 'react';
import { BookOpen, Sliders, History, Share2 } from 'lucide-react';

const Features: React.FC = () => {
  const features = [
    {
      icon: <BookOpen className="h-6 w-6 text-blue-600" />,
      title: 'Smart Summarization',
      description: 'Our AI analyzes complex articles and essays to extract the most important information.'
    },
    {
      icon: <Sliders className="h-6 w-6 text-blue-600" />,
      title: 'Tone Control',
      description: 'Choose from multiple tones including academic, casual, funny, and child-friendly.'
    },
    {
      icon: <History className="h-6 w-6 text-blue-600" />,
      title: 'Summary History',
      description: 'Access your previously generated summaries whenever you need them.'
    },
    {
      icon: <Share2 className="h-6 w-6 text-blue-600" />,
      title: 'Easy Sharing',
      description: 'Copy or share your summaries with classmates and colleagues with one click.'
    }
  ];

  return (
    <section id="features" className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-2xl font-bold text-center text-gray-900 mb-12">Key Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
              <div className="flex flex-col items-center text-center">
                <div className="mb-4 p-3 bg-blue-100 rounded-full">{feature.icon}</div>
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;