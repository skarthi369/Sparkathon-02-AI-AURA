import React from 'react';
import { BookOpen } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-gray-300 py-10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div className="flex items-center space-x-2 mb-4 md:mb-0">
            <BookOpen className="h-6 w-6" />
            <span className="text-xl font-bold tracking-tight text-white">SummarizeAI</span>
          </div>
          <nav className="flex flex-wrap justify-center gap-x-8 gap-y-4">
            <a href="#features" className="hover:text-white transition-colors">Features</a>
            <a href="#how-it-works" className="hover:text-white transition-colors">How It Works</a>
            <a href="#history" className="hover:text-white transition-colors">History</a>
          </nav>
        </div>
        <div className="border-t border-gray-800 pt-8 mt-8 text-center text-sm">
          <p>Powered by Gemini AI. Created with React and Tailwind CSS.</p>
          <p className="mt-2">&copy; {new Date().getFullYear()} SummarizeAI. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;