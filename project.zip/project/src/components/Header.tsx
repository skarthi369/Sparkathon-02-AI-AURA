import React from 'react';
import { BookOpen } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-blue-900 to-blue-800 text-white py-6 px-6 shadow-md">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <BookOpen className="h-8 w-8" />
          <h1 className="text-2xl font-bold tracking-tight">SummarizeAI</h1>
        </div>
        <div className="hidden md:flex space-x-6 text-sm">
          <a href="#features" className="hover:text-blue-200 transition-colors">Features</a>
          <a href="#how-it-works" className="hover:text-blue-200 transition-colors">How It Works</a>
          <a href="#history" className="hover:text-blue-200 transition-colors">History</a>
        </div>
      </div>
    </header>
  );
};

export default Header;