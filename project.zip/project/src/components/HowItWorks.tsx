import React from 'react';
import { FileText, Brain, Sparkles, CheckCircle } from 'lucide-react';

const HowItWorks: React.FC = () => {
  const steps = [
    {
      icon: <FileText className="h-8 w-8 text-white" />,
      title: 'Input Your Text',
      description: 'Paste your article, essay, or long text into the input area.'
    },
    {
      icon: <Brain className="h-8 w-8 text-white" />,
      title: 'Select Options',
      description: 'Choose your preferred tone and length for the summary.'
    },
    {
      icon: <Sparkles className="h-8 w-8 text-white" />,
      title: 'AI Processing',
      description: 'Our advanced AI analyzes and extracts the key information.'
    },
    {
      icon: <CheckCircle className="h-8 w-8 text-white" />,
      title: 'Get Your Summary',
      description: 'Receive a concise, well-structured summary ready to use.'
    }
  ];

  return (
    <section id="how-it-works" className="py-16 bg-gradient-to-br from-blue-900 to-blue-800 text-white">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-2xl font-bold text-center mb-16">How It Works</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {steps.map((step, index) => (
            <div key={index} className="flex flex-col items-center text-center group">
              <div className="mb-6 w-16 h-16 rounded-full bg-blue-700 flex items-center justify-center shadow-lg group-hover:bg-blue-600 transition-colors">
                {step.icon}
              </div>
              <div className="relative mb-10 w-full">
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-0 right-0 w-full h-0.5 bg-blue-700 -translate-y-8 translate-x-1/2"></div>
                )}
              </div>
              <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
              <p className="text-blue-100">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;