import React, { useState, useRef } from 'react';
import { Summary as SummaryType } from '../types';
import { Copy, Share2, CheckCircle2, Clock, FileDown, Volume2, VolumeX } from 'lucide-react';
import { jsPDF } from 'jspdf';

interface SummaryProps {
  summary: SummaryType | null;
}

const Summary: React.FC<SummaryProps> = ({ summary }) => {
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const speechSynthesisRef = useRef<SpeechSynthesisUtterance | null>(null);

  if (!summary) {
    return null;
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(summary.summarizedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: summary.title,
          text: summary.summarizedText,
        });
      } else {
        handleCopy();
      }
    } catch (error) {
      console.error('Error sharing:', error);
    }
  };

  const handleExportPDF = () => {
    const doc = new jsPDF();
    
    // Add title
    doc.setFontSize(16);
    doc.text(summary.title, 20, 20);
    
    // Add metadata
    doc.setFontSize(10);
    doc.setTextColor(100);
    const date = new Date(summary.timestamp).toLocaleString();
    doc.text(`Generated: ${date}`, 20, 30);
    doc.text(`Tone: ${summary.tone}`, 20, 35);
    doc.text(`Length: ${summary.length}`, 20, 40);
    
    // Add summary text
    doc.setFontSize(12);
    doc.setTextColor(0);
    const textLines = doc.splitTextToSize(summary.summarizedText, 170);
    doc.text(textLines, 20, 50);
    
    // Save the PDF
    doc.save(`${summary.title.toLowerCase().replace(/\s+/g, '-')}.pdf`);
  };

  const handleSpeak = () => {
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const utterance = new SpeechSynthesisUtterance(summary.summarizedText);
    utterance.onend = () => setIsSpeaking(false);
    speechSynthesisRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 animate-fade-in">
      <div className="mb-4 pb-4 border-b border-gray-200">
        <h2 className="text-xl font-bold text-gray-800 mb-2">{summary.title}</h2>
        <div className="flex flex-wrap gap-3 text-sm">
          <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full">
            {summary.tone.charAt(0).toUpperCase() + summary.tone.slice(1)} tone
          </span>
          <span className="px-3 py-1 bg-teal-100 text-teal-800 rounded-full">
            {summary.length.charAt(0).toUpperCase() + summary.length.slice(1)} length
          </span>
          <span className="px-3 py-1 bg-gray-100 text-gray-800 rounded-full flex items-center">
            <Clock className="h-3 w-3 mr-1" />
            {formatDate(summary.timestamp)}
          </span>
        </div>
      </div>

      <div className="mb-6">
        <div className="prose max-w-none text-gray-700 whitespace-pre-line">
          {summary.summarizedText}
        </div>
      </div>

      <div className="flex flex-wrap justify-end gap-3">
        <button
          onClick={handleSpeak}
          className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors flex items-center gap-2"
          aria-label={isSpeaking ? "Stop speaking" : "Speak summary"}
        >
          {isSpeaking ? (
            <>
              <VolumeX className="h-4 w-4" />
              Stop
            </>
          ) : (
            <>
              <Volume2 className="h-4 w-4" />
              Speak
            </>
          )}
        </button>
        <button
          onClick={handleExportPDF}
          className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors flex items-center gap-2"
        >
          <FileDown className="h-4 w-4" />
          Export PDF
        </button>
        <button
          onClick={handleCopy}
          className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors flex items-center gap-2"
        >
          {copied ? (
            <>
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              Copied
            </>
          ) : (
            <>
              <Copy className="h-4 w-4" />
              Copy
            </>
          )}
        </button>
        <button
          onClick={handleShare}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center gap-2"
        >
          <Share2 className="h-4 w-4" />
          Share
        </button>
      </div>
    </div>
  );
};

export default Summary;