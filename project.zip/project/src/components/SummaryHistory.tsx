import React from 'react';
import { Summary } from '../types';
import { Clock, Trash2 } from 'lucide-react';

interface SummaryHistoryProps {
  summaries: Summary[];
  onSelect: (summary: Summary) => void;
  onDelete: (id: string) => void;
  onClearAll: () => void;
}

const SummaryHistory: React.FC<SummaryHistoryProps> = ({
  summaries,
  onSelect,
  onDelete,
  onClearAll,
}) => {
  if (summaries.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-6 text-center">
        <p className="text-gray-500">No summary history yet.</p>
      </div>
    );
  }

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-gray-800">History</h2>
        <button
          onClick={onClearAll}
          className="px-3 py-1 text-sm bg-red-50 hover:bg-red-100 text-red-600 rounded-lg transition-colors flex items-center gap-1"
        >
          <Trash2 className="h-3 w-3" />
          Clear All
        </button>
      </div>

      <div className="space-y-4 max-h-96 overflow-y-auto">
        {summaries.map((summary) => (
          <div
            key={summary.id}
            className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 cursor-pointer transition-all"
            onClick={() => onSelect(summary)}
          >
            <div className="flex justify-between items-start">
              <h3 className="font-medium text-gray-800 mb-1">{summary.title}</h3>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(summary.id);
                }}
                className="text-gray-400 hover:text-red-500 p-1"
                aria-label="Delete summary"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
            <div className="text-sm text-gray-500 flex items-center gap-1 mb-2">
              <Clock className="h-3 w-3" />
              {formatDate(summary.timestamp)}
            </div>
            <div className="flex flex-wrap gap-2">
              <span className="px-2 py-0.5 text-xs bg-blue-100 text-blue-800 rounded-full">
                {summary.tone.charAt(0).toUpperCase() + summary.tone.slice(1)}
              </span>
              <span className="px-2 py-0.5 text-xs bg-teal-100 text-teal-800 rounded-full">
                {summary.length.charAt(0).toUpperCase() + summary.length.slice(1)}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SummaryHistory;