import React, { useState, useRef } from 'react';
import { SummaryLength, SummaryTone } from '../types';
import { Eraser, Loader2, Sparkles, Upload, FileText } from 'lucide-react';

interface TextInputProps {
  onSubmit: (text: string, tone: SummaryTone, length: SummaryLength) => void;
  isLoading: boolean;
}

const TextInput: React.FC<TextInputProps> = ({ onSubmit, isLoading }) => {
  const [text, setText] = useState('');
  const [tone, setTone] = useState<SummaryTone>('casual');
  const [length, setLength] = useState<SummaryLength>('medium');
  const [fileName, setFileName] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim() && !isLoading) {
      onSubmit(text, tone, length);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB');
      return;
    }

    // Check file type
    if (!['text/plain', 'application/pdf', 'application/msword', 
         'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
         .includes(file.type)) {
      alert('Please upload a text, PDF, or Word document');
      return;
    }

    setFileName(file.name);

    try {
      const text = await file.text();
      setText(text);
    } catch (error) {
      console.error('Error reading file:', error);
      alert('Error reading file. Please try again.');
    }
  };

  const toneOptions: { value: SummaryTone; label: string }[] = [
    { value: 'academic', label: 'Academic' },
    { value: 'casual', label: 'Casual' },
    { value: 'funny', label: 'Funny' },
    { value: 'child-friendly', label: 'Child-Friendly' },
    { value: 'professional', label: 'Professional' }
  ];

  const lengthOptions: { value: SummaryLength; label: string }[] = [
    { value: 'short', label: 'Short (100-150 words)' },
    { value: 'medium', label: 'Medium (200-300 words)' },
    { value: 'long', label: 'Long (400-500 words)' }
  ];

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="text-input" className="block text-sm font-medium text-gray-700 mb-2">
            Paste your article or essay here
          </label>
          <div className="relative">
            <textarea
              id="text-input"
              className="w-full h-64 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
              placeholder="Paste your long article or essay here (minimum 100 characters)..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              required
            />
            <div className="absolute inset-x-0 -bottom-8 flex items-center justify-center">
              <div className="bg-gray-50 rounded-full px-4 py-1 text-sm text-gray-500 flex items-center gap-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept=".txt,.doc,.docx,.pdf"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-1 hover:text-blue-600 transition-colors"
                >
                  <Upload className="h-4 w-4" />
                  Upload File
                </button>
                {fileName && (
                  <>
                    <span className="mx-2">|</span>
                    <span className="flex items-center gap-1">
                      <FileText className="h-4 w-4" />
                      {fileName}
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div>
            <label htmlFor="tone" className="block text-sm font-medium text-gray-700 mb-2">
              Summary Tone
            </label>
            <select
              id="tone"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
              value={tone}
              onChange={(e) => setTone(e.target.value as SummaryTone)}
            >
              {toneOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="length" className="block text-sm font-medium text-gray-700 mb-2">
              Summary Length
            </label>
            <select
              id="length"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
              value={length}
              onChange={(e) => setLength(e.target.value as SummaryLength)}
            >
              {lengthOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex justify-between">
          <button
            type="button"
            className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors flex items-center gap-2"
            onClick={() => {
              setText('');
              setFileName('');
            }}
            disabled={isLoading}
          >
            <Eraser className="h-4 w-4" />
            Clear
          </button>
          
          <button
            type="submit"
            className={`px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center gap-2 ${
              isLoading ? 'opacity-80 cursor-not-allowed' : ''
            }`}
            disabled={isLoading || text.trim().length < 100}
          >
            {isLoading ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Summarizing...
              </>
            ) : (
              <>
                <Sparkles className="h-5 w-5" />
                Summarize
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default TextInput;