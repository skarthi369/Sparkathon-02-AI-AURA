import { useState } from 'react';
import { summarizeText } from '../services/gemini';
import { Summary, SummaryLength, SummaryTone } from '../types';

export const useSummarizer = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [summaries, setSummaries] = useState<Summary[]>(() => {
    const saved = localStorage.getItem('summaries');
    return saved ? JSON.parse(saved) : [];
  });

  const generateSummary = async (
    text: string,
    tone: SummaryTone,
    length: SummaryLength
  ): Promise<Summary | null> => {
    setLoading(true);
    setError(null);
    
    try {
      // Don't summarize very short texts
      if (text.trim().length < 100) {
        setError("Please provide a longer text to summarize (at least 100 characters).");
        setLoading(false);
        return null;
      }
      
      const summarizedText = await summarizeText(text, tone, length);
      
      // Try to extract a title from the first line if it looks like a title
      let title = "Untitled Summary";
      const lines = summarizedText.split('\n');
      if (lines[0] && lines[0].length < 100 && !lines[0].endsWith('.')) {
        title = lines[0].replace(/^#+ /, ''); // Remove markdown heading symbols if present
      }
      
      const summary: Summary = {
        id: Date.now().toString(),
        originalText: text,
        summarizedText,
        tone,
        length,
        timestamp: Date.now(),
        title
      };
      
      // Save to history
      const updatedSummaries = [summary, ...summaries];
      setSummaries(updatedSummaries);
      localStorage.setItem('summaries', JSON.stringify(updatedSummaries.slice(0, 10))); // Keep only 10 most recent
      
      return summary;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      setError(errorMessage);
      return null;
    } finally {
      setLoading(false);
    }
  };

  const clearHistory = () => {
    setSummaries([]);
    localStorage.removeItem('summaries');
  };

  const deleteSummary = (id: string) => {
    const updatedSummaries = summaries.filter(summary => summary.id !== id);
    setSummaries(updatedSummaries);
    localStorage.setItem('summaries', JSON.stringify(updatedSummaries));
  };

  return {
    loading,
    error,
    summaries,
    generateSummary,
    clearHistory,
    deleteSummary
  };
};