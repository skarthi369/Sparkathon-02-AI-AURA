import { SummaryLength, SummaryTone } from '../types';

const API_KEY = 'AIzaSyBP5Dv6GNu1yZQfEY7REqlLQFJT80gE8JU';
const API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro-latest:generateContent';

interface GenerateContentRequest {
  contents: {
    parts: {
      text: string;
    }[];
  }[];
  generationConfig: {
    temperature: number;
    topK: number;
    topP: number;
    maxOutputTokens: number;
  };
}

export const summarizeText = async (
  text: string, 
  tone: SummaryTone = 'casual',
  length: SummaryLength = 'medium'
): Promise<string> => {
  try {
    const wordCountMap = {
      short: "100-150 words",
      medium: "200-300 words",
      long: "400-500 words"
    };
    
    const targetLength = wordCountMap[length];
    
    const prompt = `Summarize the following text in a ${tone} tone. 
    Make the summary approximately ${targetLength} long. 
    If possible, identify and include a title for the content.
    
    Text to summarize:
    ${text}`;

    const requestBody: GenerateContentRequest = {
      contents: [
        {
          parts: [
            {
              text: prompt
            }
          ]
        }
      ],
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 1024
      }
    };

    const response = await fetch(`${API_URL}?key=${API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`API request failed: ${response.status} - ${JSON.stringify(errorData)}`);
    }

    const data = await response.json();
    
    if (!data.candidates?.[0]?.content?.parts?.[0]?.text) {
      throw new Error('Invalid response format from API');
    }

    return data.candidates[0].content.parts[0].text;
  } catch (error) {
    console.error('Error summarizing text:', error);
    throw new Error('Failed to generate summary. Please try again later.');
  }
};