export type SummaryLength = 'short' | 'medium' | 'long';

export type SummaryTone = 'academic' | 'casual' | 'funny' | 'child-friendly' | 'professional';

export interface Summary {
  id: string;
  originalText: string;
  summarizedText: string;
  tone: SummaryTone;
  length: SummaryLength;
  timestamp: number;
  title: string;
}